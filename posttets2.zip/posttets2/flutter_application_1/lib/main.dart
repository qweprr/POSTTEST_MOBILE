import 'package:flutter/material.dart';

void main() {
  runApp(const JerseyStoreApp());
}

class Product {
  final String name;
  final String category;
  final int price;
  int stock;
  final IconData icon;

  Product({
    required this.name,
    required this.category,
    required this.price,
    required this.stock,
    required this.icon,
  });
}

class JerseyStoreApp extends StatelessWidget {
  const JerseyStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JerseyStore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.red,
        ),
        useMaterial3: true,
      ),
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int currentIndex = 0;

  final List<Product> products = [
    Product(
      name: 'Jersey Home',
      category: 'Football',
      price: 249000,
      stock: 10,
      icon: Icons.checkroom,
    ),
    Product(
      name: 'Jersey Away',
      category: 'Football',
      price: 279000,
      stock: 8,
      icon: Icons.checkroom,
    ),
    Product(
      name: 'Jersey Basketball',
      category: 'Basketball',
      price: 259000,
      stock: 6,
      icon: Icons.sports_basketball,
    ),
    Product(
      name: 'Jersey Indonesia',
      category: 'Football',
      price: 299000,
      stock: 5,
      icon: Icons.flag,
    ),
    Product(
      name: 'Jersey Running',
      category: 'Running',
      price: 219000,
      stock: 7,
      icon: Icons.directions_run,
    ),
  ];

  final Map<String, int> cart = {};

  int get totalCartItems {
    int total = 0;

    cart.forEach((key, value) {
      total += value;
    });

    return total;
  }

  int get grandTotal {
    int total = 0;

    for (final product in products) {
      final quantity = cart[product.name] ?? 0;
      total += product.price * quantity;
    }

    return total;
  }

  void addToCart(Product product) {
    setState(() {
      final currentQuantity = cart[product.name] ?? 0;

      if (currentQuantity < product.stock) {
        cart[product.name] = currentQuantity + 1;
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product.name} ditambahkan ke keranjang'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void changeQuantity(Product product, int quantity) {
    setState(() {
      if (quantity <= 0) {
        cart.remove(product.name);
      } else if (quantity <= product.stock) {
        cart[product.name] = quantity;
      }
    });
  }

  void removeFromCart(Product product) {
    setState(() {
      cart.remove(product.name);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: currentIndex,
        children: [
          HomePage(
            products: products,
            onAddToCart: addToCart,
          ),
          ExplorePage(
            products: products,
            onAddToCart: addToCart,
          ),
          CartPage(
            products: products,
            cart: cart,
            grandTotal: grandTotal,
            onQuantityChanged: changeQuantity,
            onRemove: removeFromCart,
          ),
          const ProfilePage(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        items: [
          const BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Home',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.explore_outlined),
            activeIcon: Icon(Icons.explore),
            label: 'Explore',
          ),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$totalCartItems'),
              isLabelVisible: totalCartItems > 0,
              child: const Icon(Icons.shopping_cart_outlined),
            ),
            activeIcon: Badge(
              label: Text('$totalCartItems'),
              isLabelVisible: totalCartItems > 0,
              child: const Icon(Icons.shopping_cart),
            ),
            label: 'Cart',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<Product> products;
  final Function(Product) onAddToCart;

  const HomePage({
    super.key,
    required this.products,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Selamat Datang!',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'JerseyStore',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.shopping_bag_outlined,
                        size: 26,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.red.shade700,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Jersey Terbaru',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Dapatkan diskon hingga 30%',
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 14),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ExplorePage(
                                      products: products,
                                      onAddToCart: onAddToCart,
                                    ),
                                  ),
                                );
                              },
                              child: const Text('Belanja Sekarang'),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.sports_soccer,
                        color: Colors.white,
                        size: 65,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                const Text(
                  'Kategori',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _categoryItem(
                        Icons.sports_soccer,
                        'Football',
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _categoryItem(
                        Icons.sports_basketball,
                        'Basketball',
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _categoryItem(
                        Icons.directions_run,
                        'Running',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                const Text(
                  'Jersey Populer',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _productCard(
                        products[0],
                        onAddToCart,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _productCard(
                        products[1],
                        onAddToCart,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _categoryItem(
    IconData icon,
    String title,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 28,
            color: Colors.red.shade700,
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _productCard(
    Product product,
    Function(Product) onAddToCart,
  ) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                product.icon,
                size: 55,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              product.name,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              formatRupiah(product.price),
              style: TextStyle(
                color: Colors.red.shade700,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: product.stock > 0
                    ? () => onAddToCart(product)
                    : null,
                child: const Text('Tambah'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ExplorePage extends StatefulWidget {
  final List<Product> products;
  final Function(Product) onAddToCart;

  const ExplorePage({
    super.key,
    required this.products,
    required this.onAddToCart,
  });

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  late TextEditingController searchController;

  String searchQuery = '';

  @override
  void initState() {
    super.initState();

    searchController = TextEditingController();
  }

  @override
  void dispose() {
    searchController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visibleProducts = widget.products.where((product) {
      return product.stock > 0 &&
          product.name.toLowerCase().contains(
                searchQuery.toLowerCase(),
              );
    }).toList();

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Explore Jersey',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Cari Jersey',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: searchController,
                onChanged: (value) {
                  setState(() {
                    searchQuery = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Cari jersey...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: searchQuery.isNotEmpty
                      ? IconButton(
                          onPressed: () {
                            searchController.clear();

                            setState(() {
                              searchQuery = '';
                            });
                          },
                          icon: const Icon(Icons.clear),
                        )
                      : null,
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                searchQuery.isEmpty
                    ? 'Semua Produk'
                    : 'Hasil untuk "$searchQuery"',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 14),
              if (visibleProducts.isEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(30),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Column(
                    children: [
                      Icon(
                        Icons.search_off,
                        size: 60,
                        color: Colors.grey,
                      ),
                      SizedBox(height: 12),
                      Text(
                        'Produk tidak ditemukan',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: visibleProducts.length,
                itemBuilder: (context, index) {
                  final product = visibleProducts[index];

                  return ProductExploreCard(
                    product: product,
                    onAddToCart: widget.onAddToCart,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProductExploreCard extends StatefulWidget {
  final Product product;
  final Function(Product) onAddToCart;

  const ProductExploreCard({
    super.key,
    required this.product,
    required this.onAddToCart,
  });

  @override
  State<ProductExploreCard> createState() =>
      _ProductExploreCardState();
}

class _ProductExploreCardState extends State<ProductExploreCard> {
  late TextEditingController quantityController;

  int quantity = 1;

  @override
  void initState() {
    super.initState();

    quantityController = TextEditingController(
      text: '$quantity',
    );
  }

  @override
  void didUpdateWidget(
    covariant ProductExploreCard oldWidget,
  ) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.product.stock != widget.product.stock) {
      quantity = 1;
      quantityController.text = '$quantity';
    }
  }

  @override
  void dispose() {
    quantityController.dispose();

    super.dispose();
  }

  void updateQuantity(String value) {
    final parsed = int.tryParse(value);

    if (parsed == null || parsed < 1) {
      return;
    }

    setState(() {
      quantity = parsed.clamp(1, widget.product.stock);
      quantityController.text = '$quantity';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 75,
                  height: 75,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    widget.product.icon,
                    size: 40,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.product.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        widget.product.category,
                        style: TextStyle(
                          color: Colors.grey.shade600,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        formatRupiah(widget.product.price),
                        style: TextStyle(
                          color: Colors.red.shade700,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text(
                  'Jumlah:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 70,
                  child: TextField(
                    controller: quantityController,
                    keyboardType: TextInputType.number,
                    onChanged: updateQuantity,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 10,
                      ),
                    ),
                  ),
                ),
                const Spacer(),
                ElevatedButton(
                  onPressed: widget.product.stock > 0
                      ? () {
                          for (int i = 0; i < quantity; i++) {
                            widget.onAddToCart(widget.product);
                          }
                        }
                      : null,
                  child: const Text('Tambah'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CartPage extends StatefulWidget {
  final List<Product> products;
  final Map<String, int> cart;
  final int grandTotal;
  final Function(Product, int) onQuantityChanged;
  final Function(Product) onRemove;

  const CartPage({
    super.key,
    required this.products,
    required this.cart,
    required this.grandTotal,
    required this.onQuantityChanged,
    required this.onRemove,
  });

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  bool isCheckingOut = false;

  void checkout() {
    if (widget.grandTotal <= 0) {
      return;
    }

    setState(() {
      isCheckingOut = true;
    });

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Checkout Berhasil'),
          content: Text(
            'Total pembayaran: '
            '${formatRupiah(widget.grandTotal)}',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);

                setState(() {
                  isCheckingOut = false;
                });
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartProducts = widget.products.where((product) {
      return widget.cart.containsKey(product.name);
    }).toList();

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Keranjang',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: cartProducts.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.shopping_cart_outlined,
                    size: 80,
                    color: Colors.grey,
                  ),
                  SizedBox(height: 16),
                  Text(
                    'Keranjang masih kosong',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: cartProducts.length,
                    itemBuilder: (context, index) {
                      final product = cartProducts[index];
                      final quantity =
                          widget.cart[product.name] ?? 0;

                      return CartProductCard(
                        product: product,
                        quantity: quantity,
                        maxQuantity: product.stock,
                        onQuantityChanged: (newQuantity) {
                          widget.onQuantityChanged(
                            product,
                            newQuantity,
                          );
                        },
                        onRemove: () {
                          widget.onRemove(product);
                        },
                      );
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total Belanja'),
                          Text(
                            formatRupiah(widget.grandTotal),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed:
                              widget.grandTotal > 0 &&
                                      !isCheckingOut
                                  ? checkout
                                  : null,
                          child: Text(
                            isCheckingOut
                                ? 'Memproses...'
                                : 'Checkout',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class CartProductCard extends StatefulWidget {
  final Product product;
  final int quantity;
  final int maxQuantity;
  final Function(int) onQuantityChanged;
  final VoidCallback onRemove;

  const CartProductCard({
    super.key,
    required this.product,
    required this.quantity,
    required this.maxQuantity,
    required this.onQuantityChanged,
    required this.onRemove,
  });

  @override
  State<CartProductCard> createState() =>
      _CartProductCardState();
}

class _CartProductCardState extends State<CartProductCard> {
  late TextEditingController quantityController;

  @override
  void initState() {
    super.initState();

    quantityController = TextEditingController(
      text: '${widget.quantity}',
    );
  }

  @override
  void didUpdateWidget(
    covariant CartProductCard oldWidget,
  ) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.quantity != widget.quantity) {
      quantityController.text = '${widget.quantity}';
    }
  }

  @override
  void dispose() {
    quantityController.dispose();

    super.dispose();
  }

  void updateQuantity(String value) {
    final parsed = int.tryParse(value);

    if (parsed == null || parsed < 1) {
      return;
    }

    final newQuantity = parsed.clamp(
      1,
      widget.maxQuantity,
    );

    widget.onQuantityChanged(newQuantity);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 75,
              height: 75,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                widget.product.icon,
                size: 40,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.product.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    formatRupiah(widget.product.price),
                    style: TextStyle(
                      color: Colors.red.shade700,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      IconButton(
                        onPressed: widget.quantity > 1
                            ? () {
                                widget.onQuantityChanged(
                                  widget.quantity - 1,
                                );
                              }
                            : null,
                        icon: const Icon(
                          Icons.remove_circle_outline,
                        ),
                      ),
                      SizedBox(
                        width: 45,
                        child: TextField(
                          controller: quantityController,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.number,
                          onChanged: updateQuantity,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed:
                            widget.quantity <
                                    widget.maxQuantity
                                ? () {
                                    widget.onQuantityChanged(
                                      widget.quantity + 1,
                                    );
                                  }
                                : null,
                        icon: const Icon(
                          Icons.add_circle_outline,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: widget.onRemove,
              icon: const Icon(
                Icons.delete_outline,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundColor: Colors.red,
                child: Icon(
                  Icons.person,
                  size: 55,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'JerseyStore User',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                'user@jerseystore.com',
                style: TextStyle(
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(height: 30),
              Card(
                child: Column(
                  children: [
                    const ListTile(
                      leading: Icon(Icons.person_outline),
                      title: Text('Informasi Akun'),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                      ),
                    ),
                    const Divider(height: 1),
                    const ListTile(
                      leading: Icon(
                        Icons.location_on_outlined,
                      ),
                      title: Text('Alamat Pengiriman'),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                      ),
                    ),
                    const Divider(height: 1),
                    const ListTile(
                      leading: Icon(
                        Icons.receipt_long_outlined,
                      ),
                      title: Text('Riwayat Pesanan'),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                      ),
                    ),
                    const Divider(height: 1),
                    const ListTile(
                      leading: Icon(Icons.settings_outlined),
                      title: Text('Pengaturan'),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String formatRupiah(int value) {
  final text = value.toString();
  final buffer = StringBuffer();

  for (int i = 0; i < text.length; i++) {
    if (i > 0 && (text.length - i) % 3 == 0) {
      buffer.write('.');
    }

    buffer.write(text[i]);
  }

  return 'Rp${buffer.toString()}';
}